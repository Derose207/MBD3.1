﻿using MDB.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.ConstrainedExecution;
using System.Runtime.InteropServices;
using System.Web.Mvc;

namespace MDB.Controllers
{
    public class AccountsController : Controller
    {
        private readonly AppDBEntities DB = new AppDBEntities();

        [HttpPost]
        public JsonResult EmailExist(string email)
        {
            return Json(DB.EmailExist(email));
        }

        [HttpPost]
        public JsonResult EmailAvailable(string email, int id)
        {
            return Json(DB.EmailAvailable(email, id));
        }

        #region Login and Logout
        public ActionResult Login(string message)
        {
            LoginCredential credential = new LoginCredential();
            ViewBag.Message = message;

            return View(credential);
        }
        [HttpPost]
        [ValidateAntiForgeryToken()]
        public ActionResult Login(LoginCredential loginCredential)
        {
            if (ModelState.IsValid)
            {
                if (DB.EmailBlocked(loginCredential.Email))
                {
                    ModelState.AddModelError("Email", "Ce compte est bloqué.");
                    return View(loginCredential);
                }
                if (!DB.EmailVerified(loginCredential.Email))
                {
                    ModelState.AddModelError("Email", "Ce courriel n'est pas vérifié.");
                    return View(loginCredential);
                }
                User user = DB.GetUser(loginCredential);
                if (user == null)
                {
                    ModelState.AddModelError("Password", "Mot de passe incorrecte.");
                    return View(loginCredential);
                }
                if (OnlineUsers.IsOnLine(user.Id))
                {
                    ModelState.AddModelError("Email", "Cet usager est déjà connecté.");
                    return View(loginCredential);
                }
                OnlineUsers.AddSessionUser(user.Id);
                Session["currentLoginId"] = DB.AddLogin(user.Id).Id;
                return RedirectToAction("Index", "Movies");
            }
            return View(loginCredential);
        }
        public ActionResult Logout()
        {
            if (Session["currentLoginId"] != null)
                DB.UpdateLogout((int)Session["currentLoginId"]);
            OnlineUsers.RemoveSessionUser();
            return RedirectToAction("Login");
        }
        #endregion
        public ActionResult Subscribe()
        {
            ViewBag.Genders = SelectListUtilities<Gender>.Convert(DB.Genders.ToList());
            return View(new User());
        }
        [HttpPost]
        public ActionResult Subscribe(User user)
        {
            if (ModelState.IsValid)
            {
                // Evoyer Email 
                // SMTP.SendEmail(user.FirstName, user.Email, user.FirstName, user.LastName);

                DB.AddUser(user);
                SendEmailVerification(user, user.Email);

                //  string statusMessage = "Message envoyé a  avec succès";



                return RedirectToAction("SubscribeDone");
            }

            return View(user);
        }
        public ActionResult SubscribeDone()
        {
            // User user = User.Find
            //ViewBag.Genders = SelectListUtilities<Gender>.Convert(DB.Genders.ToList());
            return View(new User());
        }
        [HttpPost]
        public ActionResult SubscribeDone(User user)
        {
            if (ModelState.IsValid)
            {
                // Evoyer Email 
                // SMTP.SendEmail(user.FirstName, user.Email, user.FirstName, user.LastName);

                // DB.AddUser(user);
                //SendEmailVerification(user, user.Email);


                return RedirectToAction("Login");
            }

            return View(user);
        }

        public ActionResult VerifyDone()
        {
            //ViewBag.Genders = SelectListUtilities<Gender>.Convert(DB.Genders.ToList());
            return View(new User());
        }
        [HttpPost]
        public ActionResult VerifyDone(User user)
        {
            if (ModelState.IsValid)
            {
                // Evoyer Email 
                // SMTP.SendEmail(user.FirstName, user.Email, user.FirstName, user.LastName);

                // DB.AddUser(user);
                //SendEmailVerification(user, user.Email);


                return RedirectToAction("SubscribeDone");
            }

            return View(user);
        }
        public void SendEmailVerification(User user, string newEmail)
        {
            if (user.Id != 0)
            {
                UnverifiedEmail unverifiedEmail = DB.Add_UnverifiedEmail(user.Id, newEmail);
                if (unverifiedEmail != null)
                {
                    string verificationUrl = Url.Action("VerifyUser", "Accounts", null, Request.Url.Scheme);
                    String Link = @"<br/><a href='" + verificationUrl + "?userid=" + user.Id + "&code=" + unverifiedEmail.VerificationCode + @"' > Confirmez votre inscription...</a>";

                    String suffixe = "";
                    if (user.GenderId == 2)
                    {
                        suffixe = "e";
                    }
                    string Subject = "MDB - Vérification d'inscription...";

                    string Body = "Bonjour " + user.GetFullName(true) + @",<br/><br/>";
                    Body += @"Merci de vous être inscrit" + suffixe + " au site MDB. <br/>";
                    Body += @"Pour utiliser votre compte vous devez confirmer votre inscription en cliquant sur le lien suivant : <br/>";
                    Body += Link;
                    Body += @"<br/><br/>Ce courriel a été généré automatiquement, veuillez ne pas y répondre.";
                    Body += @"<br/><br/>Si vous éprouvez des difficultés ou s'il s'agit d'une erreur, veuillez le signaler à <a href='mailto:"
                         + SMTP.OwnerEmail + "'>" + SMTP.OwnerName + "</a> (Webmestre du site MDB)";

                    SMTP.SendEmail(user.GetFullName(), unverifiedEmail.Email, Subject, Body);
                }
            }
        }
        public ActionResult VerifyUser()
        {

            int userId = 0;
            int code = 0;

            if (int.TryParse(Request.QueryString["userid"], out userId) && int.TryParse(Request.QueryString["code"], out code))
            {

                AppDBDAL.VerifyUser(DB, userId, code);

            }
            else
            {
                // Les valeurs des paramètres "userid" et "code" ne sont pas des entiers valides
                // Gérer l'erreur ou rediriger l'utilisateur vers une page d'erreur appropriée
                // ...
            }

            return View();

        }
        [HttpPost]
        public ActionResult VerifyUser(User user)
        {
            if (ModelState.IsValid)
            {




                return RedirectToAction("VerifyDone");
            }

            return RedirectToAction("VerifyDone");
        }


    /*    [OnlineUsers.UserAccess]
        public ActionResult Profil()
        {
            ViewBag.Genders = SelectListUtilities<Gender>.Convert(DB.Genders.ToList());
            User userToEdit = OnlineUsers.GetSessionUser();

            if (userToEdit != null)
            {
                Session["currentUserPassword"] = userToEdit.Password;
                Session["UnchangedPasswordCode"] = Guid.NewGuid().ToString().Substring(0, 12);
                userToEdit.Password = userToEdit.ConfirmPassword = (string)Session["UnchangedPasswordCode"];
                return View(userToEdit);
            }
            return null;
        }
        [HttpPost]
        public ActionResult Profil(User user)
        {
            User userToEdit = OnlineUsers.GetSessionUser();
            if (ModelState.IsValid)
            {
                DB.UpdateUser(userToEdit);
            }

            return View();
        }

        */

    }
}